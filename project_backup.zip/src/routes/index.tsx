import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect } from "react";
import { Button } from "@/components/ui/button";
import { trackEvent } from "@/lib/analytics";
import { useTranslation } from "react-i18next";
import { LanguageSwitcher } from "@/components/LanguageSwitcher";


export const Route = createFileRoute("/")({
  component: LandingPage,
});

function LandingPage() {
  const navigate = useNavigate();
  const { t } = useTranslation();


  useEffect(() => {
    trackEvent('landing_view');
  }, []);

  return (
    <div className="min-h-screen bg-[#F7F3EA] flex flex-col items-center px-4 py-8 md:p-12 text-center relative overflow-hidden">
      {/* Overlay de carregamento para evitar flashes de conteúdo não traduzido */}
      {!t('common:landing_title') || t('common:landing_title') === 'landing_title' ? (
        <div className="fixed inset-0 bg-[#F7F3EA] z-[9999] flex items-center justify-center">
          <div className="animate-pulse text-primary font-bold">Carregando...</div>
        </div>
      ) : null}

      {/* Header com seletor de idioma - Elegante e discreto */}
      <header className="w-full max-w-5xl flex justify-center md:justify-end mb-8 md:mb-12 animate-fade-in relative z-50">
        <LanguageSwitcher />
      </header>

      <main className="flex-1 flex flex-col items-center justify-center w-full max-w-4xl mx-auto">
        <div className="w-20 h-20 md:w-24 md:h-24 bg-primary/10 rounded-full flex items-center justify-center mb-6 md:mb-8 shadow-inner animate-bounce-subtle shrink-0">
          <span className="text-4xl md:text-5xl">🧠</span>
        </div>
        
        <h1 className="text-3xl sm:text-4xl md:text-6xl font-black text-[#1F2937] mb-6 md:mb-8 tracking-tight max-w-3xl leading-[1.1] animate-fade-up">
          {t('common:landing_title')}
        </h1>
        
        <div className="space-y-4 md:space-y-6 mb-8 md:mb-12 text-left max-w-md w-full animate-fade-up px-2" style={{ animationDelay: '0.2s' }}>
          {[
            t('common:landing_item_1'),
            t('common:landing_item_2'),
          ].map((item) => (
            <div key={item} className="flex items-start space-x-3 text-lg sm:text-xl md:text-2xl text-gray-700 font-semibold bg-white/50 p-4 md:p-5 rounded-2xl shadow-sm border border-white transition-transform hover:scale-[1.02]">
              <span className="shrink-0 text-primary mt-1">✨</span>
              <span>{item}</span>
            </div>
          ))}
        </div>

        <p className="text-lg sm:text-xl md:text-2xl text-gray-600 mb-8 md:mb-10 max-w-lg leading-relaxed animate-fade-up px-4" style={{ animationDelay: '0.4s' }}>
          {t('common:landing_subtitle')}
        </p>
        
        <div className="space-y-4 w-full max-w-xs animate-fade-up px-4" style={{ animationDelay: '0.6s' }}>
          <Button 
            onClick={() => navigate({ to: "/game", search: { mode: 'trial' } })}
            className="w-full bg-primary hover:bg-primary/90 text-white text-xl md:text-2xl py-6 md:py-8 px-8 rounded-full shadow-lg transition-all hover:scale-[1.02] active:scale-95 font-bold uppercase tracking-widest h-auto border-b-4 border-black/10"
          >
            {t('common:start_test')}
          </Button>
          <p className="text-sm md:text-base font-medium text-gray-500">{t('common:free_test_info')}</p>
        </div>
        <div className="mt-16 text-gray-400 font-medium animate-fade-in" style={{ animationDelay: '1s' }}>
          {t('common:made_for_50plus')}
        </div>
      </main>

      {/* Background decoration */}
      <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] bg-primary/5 rounded-full blur-3xl -z-10" />
      <div className="absolute bottom-[-10%] right-[-10%] w-[40%] h-[40%] bg-primary/5 rounded-full blur-3xl -z-10" />
    </div>
  );
}