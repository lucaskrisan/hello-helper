import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { supabase } from "@/integrations/supabase/client";
import { GAME_ASSETS } from "@/lib/game-engine";
import { Settings, BarChart3, Home as HomeIcon, ShieldCheck } from "lucide-react";
import { useTranslation } from "react-i18next";


export const Route = createFileRoute("/dashboard")({
  component: Dashboard,
});

function Dashboard() {
  const { t, i18n } = useTranslation();
  const [profile, setProfile] = useState<any>(null);
  const [streak, setStreak] = useState<any>(null);
  const [challenges, setChallenges] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();


  useEffect(() => {
    async function loadData() {
      setLoading(true);
      const { data: { user } } = await supabase.auth.getUser();

      if (!user) {
        navigate({ to: "/login", replace: true });
        return;
      }

      const { data: prof } = await supabase.from("profiles").select("*").eq("user_id", user.id).maybeSingle();
      if (!prof) {
        navigate({ to: "/onboarding", replace: true });
        return;
      }

      const [{ data: str }, { data: challs }] = await Promise.all([
        supabase.from("streaks").select("*").eq("user_id", user.id).maybeSingle(),
        supabase.from("daily_challenges").select("*").eq("user_id", user.id).order('created_at', { ascending: false })
      ]);

      const currentProfile = { ...prof, email: user.email };
      const currentStreak = str || { current_streak: 0 };
      const currentChallengesList = challs || [];

      setProfile(currentProfile);
      setStreak(currentStreak);
      setChallenges(currentChallengesList);
      setLoading(false);
    }
    loadData();
  }, [navigate]);

  const today = new Date();
  const daysInMonth = new Date(today.getFullYear(), today.getMonth() + 1, 0).getDate();
  const currentDay = today.getDate();
  const completedDays = challenges.map(c => new Date(c.created_at).getDate());

  if (loading) {
    return (
      <div className="min-h-screen bg-[#F7F3EA] flex items-center justify-center p-6">
        <div className="w-12 h-12 border-4 border-primary border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#F7F3EA] p-4 sm:p-6 md:p-8 max-w-2xl mx-auto pb-32 overflow-x-hidden">
      <header className="flex justify-between items-start md:items-center mb-8 gap-4">
        <div className="flex-1">
          <h1 className="text-xl sm:text-2xl md:text-3xl font-black text-[#1F2937] leading-tight">{t('dashboard_greeting')}{profile?.display_name || profile?.name ? `, ${profile.display_name || profile.name}` : ""}! 👋</h1>
          <p className="text-gray-500 text-sm sm:text-base font-medium mt-1">{t('dashboard_subtitle')}</p>

        </div>
        <div className="bg-white p-3 rounded-2xl shadow-sm flex items-center space-x-2 border border-white/50">
          <span className="text-2xl">🔥</span>
          <span className="font-bold text-xl text-[#D97706]">{streak?.current_streak || 0}</span>
        </div>
      </header>

      <Card className="p-6 bg-white rounded-3xl shadow-sm mb-8 border-none overflow-hidden relative">
        <div className="absolute top-0 right-0 w-32 h-32 bg-primary/5 rounded-full -mr-16 -mt-16" />
        <h2 className="font-bold text-lg mb-4 flex items-center space-x-2">
          <span>📅</span>
          <span>{t('dashboard_progress_month', { month: today.toLocaleDateString(i18n.language, { month: 'long' }) })}</span>
        </h2>
        <div className="grid grid-cols-7 gap-1.5 sm:gap-2">
          {Array.from({ length: daysInMonth }).map((_, i) => {
            const day = i + 1;
            const isToday = day === currentDay;
            const isCompleted = completedDays.includes(day);
            return (
              <div 
                key={day} 
                className={`h-9 sm:h-11 flex items-center justify-center rounded-lg sm:rounded-xl text-xs sm:text-sm font-bold transition-all ${
                  isToday ? "bg-primary text-white shadow-lg scale-105 sm:scale-110 ring-2 ring-primary/20" : 
                  isCompleted ? "bg-primary/20 text-primary" : "bg-gray-50 text-gray-300"
                }`}
              >
                {day}
              </div>
            );
          })}
        </div>
      </Card>

      <Button 
        onClick={() => navigate({ to: "/game", search: { mode: 'daily' } })}
        className="w-full py-10 sm:py-12 md:py-14 text-xl sm:text-2xl md:text-3xl font-black bg-primary hover:bg-primary/90 text-white rounded-[2rem] sm:rounded-[3rem] shadow-xl mb-8 sm:mb-12 transform transition-all hover:scale-[1.02] active:scale-95 flex flex-col space-y-2 relative overflow-hidden h-auto uppercase tracking-wider"
      >
        <div className="absolute inset-0 bg-white/10 opacity-0 hover:opacity-100 transition-opacity" />
        <span className="relative z-10">{t('dashboard_start_challenge')}</span>
        <span className="text-xs sm:text-sm font-medium opacity-80 relative z-10 normal-case">{t('dashboard_start_info')}</span>
      </Button>

      <h3 className="text-xl font-bold mb-6 text-[#1F2937] flex items-center space-x-2">
        <span className="text-2xl">🧩</span>
        <span>{t('dashboard_categories')}</span>
      </h3>
      <div className="grid grid-cols-1 gap-4">
        {GAME_ASSETS.categories.map((cat) => (
          <Button
            key={cat.id}
            onClick={() => navigate({ to: "/game", search: { mode: 'category', categoryId: cat.id } })}
            className="h-auto p-4 sm:p-5 bg-white hover:bg-gray-50 text-left justify-start border-none rounded-2xl sm:rounded-3xl shadow-sm flex items-center space-x-3 sm:space-x-4 transition-all hover:translate-x-1 group"
          >
            <div className="text-3xl sm:text-4xl p-3 sm:p-4 rounded-xl sm:rounded-2xl transition-transform group-hover:scale-110" style={{ backgroundColor: `${cat.color}15`, color: cat.color }}>
              {cat.icon}
            </div>
            <div className="flex flex-col flex-1 min-w-0">
              <span className="text-base sm:text-lg font-bold text-[#1F2937] truncate">{t(`category_${cat.id}`, cat.name)}</span>
              <span className="text-xs sm:text-sm text-gray-500 font-normal line-clamp-1">{t(`category_desc_${cat.id}`, cat.description)}</span>
            </div>
            <div className="w-7 h-7 sm:w-8 sm:h-8 rounded-full bg-gray-50 flex items-center justify-center text-gray-300 shrink-0">
              →
            </div>
          </Button>
        ))}
      </div>


      {profile?.is_admin && (
        <Button
          onClick={() => navigate({ to: "/admin" })}
          className="w-full mt-4 bg-gray-900 hover:bg-gray-800 text-white rounded-2xl py-4 flex items-center justify-center gap-2"
        >
          <ShieldCheck className="w-5 h-5 text-primary" />
          {t('dashboard_admin_button')}
        </Button>
      )}

      <div className="fixed bottom-0 left-0 right-0 p-6 z-50 pointer-events-none">
        <nav className="max-w-md mx-auto bg-white/90 backdrop-blur-lg p-3 rounded-[2.5rem] shadow-2xl flex justify-around items-center border border-white/50 pointer-events-auto">
          <button 
            onClick={() => navigate({ to: "/dashboard" })} 
            className="flex flex-col items-center p-2 text-primary transition-transform active:scale-90"
          >
            <HomeIcon className="w-6 h-6 mb-1" />
            <span className="text-[10px] font-bold uppercase tracking-wider">{t('nav_home')}</span>
          </button>
          <button 
            onClick={() => navigate({ to: "/progresso" })} 
            className="flex flex-col items-center p-2 text-gray-400 hover:text-primary transition-all active:scale-90"
          >
            <BarChart3 className="w-6 h-6 mb-1" />
            <span className="text-[10px] font-bold uppercase tracking-wider">{t('nav_progress')}</span>
          </button>
          <button 
            onClick={() => navigate({ to: "/settings" })} 
            className="flex flex-col items-center p-2 text-gray-400 hover:text-primary transition-all active:scale-90"
          >
            <Settings className="w-6 h-6 mb-1" />
            <span className="text-[10px] font-bold uppercase tracking-wider">{t('nav_settings')}</span>

          </button>
        </nav>
      </div>
    </div>
  );
}
