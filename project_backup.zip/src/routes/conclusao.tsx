import { createFileRoute, useNavigate, useSearch } from "@tanstack/react-router";
import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Check, Star, Mail } from "lucide-react";
import { trackEvent } from "@/lib/analytics";
import { useTranslation } from "react-i18next";
import { getCurrencySymbol } from "@/i18n/detect-country";


export const Route = createFileRoute("/conclusao")({
  component: Conclusion,
  validateSearch: (search: Record<string, unknown>) => {
    return {
      score: (search.score as number) || 0,
      time: (search.time as number) || 0,
    };
  },
});

function Conclusion() {
  const navigate = useNavigate();
  const search = useSearch({ from: "/conclusao" });
  const { t } = useTranslation();
  const { score, time } = search;
  const [step, setStep] = useState<'report' | 'explanation' | 'offer'>('report');

  const renderStars = (count: number) => (
    <div className="flex space-x-1">
      {[1, 2, 3, 4, 5].map((s) => (
        <Star key={s} className={`w-5 h-5 ${s <= count ? "text-yellow-400 fill-yellow-400" : "text-gray-200"}`} />
      ))}
    </div>
  );

  useEffect(() => {
    if (step === 'report') trackEvent('result_viewed');
    if (step === 'offer') trackEvent('offer_viewed');
  }, [step]);

  if (step === 'report') {
    return (
      <div className="min-h-screen bg-[#F7F3EA] p-4 sm:p-6 md:p-8 flex flex-col items-center justify-center">
        <Card className="w-full max-w-md p-6 sm:p-10 bg-white rounded-[2rem] sm:rounded-[3rem] shadow-xl text-center border-none">
          <h1 className="text-2xl sm:text-3xl font-black mb-6 text-[#1F2937] leading-tight">{t('conclusion_profile_title')}</h1>
          
          <div className="space-y-6 mb-8 text-left">
            <div className="flex justify-between items-center p-3 bg-gray-50 rounded-xl border border-gray-100">
              <span className="font-medium">{t('conclusion_memory')}</span>
              {renderStars(Math.max(1, Math.floor((score / 20) - (time > 120 ? 1 : 0))))}
            </div>
            <div className="flex justify-between items-center p-3 bg-gray-50 rounded-xl border border-gray-100">
              <span className="font-medium">{t('conclusion_attention')}</span>
              {renderStars(Math.max(1, Math.floor(score / 20)))}
            </div>
            <div className="flex justify-between items-center p-3 bg-gray-50 rounded-xl border border-gray-100">
              <span className="font-medium">{t('conclusion_logic')}</span>
              {renderStars(Math.max(1, Math.floor(score / 20)))}
            </div>
            <div className="flex justify-between items-center p-3 bg-gray-50 rounded-xl border border-gray-100">
              <span className="font-medium">{t('conclusion_speed')}</span>
              {renderStars(time < 60 ? 5 : time < 100 ? 4 : time < 150 ? 3 : 2)}
            </div>
          </div>

          <div className="bg-orange-50 p-6 rounded-2xl mb-8 text-left border-l-4 border-orange-500">
            <p className="text-orange-900 font-medium leading-relaxed">
              {t('conclusion_diagnosis')}
            </p>
            <p className="text-orange-900 font-bold mt-4 italic">
              {t('conclusion_warning')}
            </p>
          </div>

          <Button 
            onClick={() => setStep('explanation')}
            className="w-full py-8 md:py-10 text-xl font-black bg-primary hover:bg-primary/90 text-white rounded-2xl md:rounded-[2rem] shadow-xl transition-all hover:scale-105 active:scale-95 uppercase tracking-widest h-auto"
          >
            {t('conclusion_continue')}
          </Button>
        </Card>
      </div>
    );
  }

  if (step === 'explanation') {
    return (
      <div className="min-h-screen bg-[#F7F3EA] p-4 sm:p-6 md:p-8 flex flex-col items-center justify-center">
        <Card className="w-full max-w-md p-6 sm:p-10 bg-white rounded-[2rem] sm:rounded-[3rem] shadow-xl text-center border-none">
          <h1 className="text-2xl sm:text-3xl font-black mb-6 text-[#1F2937] leading-tight">{t('conclusion_what_means_title')}</h1>
          
          <div className="space-y-4 text-left mb-8">
            <p className="text-gray-700 leading-relaxed text-lg">
              {t('conclusion_explain_1')}
            </p>
            <p className="text-gray-700 leading-relaxed text-lg">
              {t('conclusion_explain_2')}
            </p>
            <p className="text-gray-700 leading-relaxed text-lg font-medium">
              {t('conclusion_explain_3')}
            </p>
          </div>

          <div className="bg-green-50 p-6 rounded-2xl mb-8 text-left">
            <p className="font-bold text-green-800 mb-4">{t('conclusion_next_30')}</p>
            <ul className="space-y-3">
              <li className="flex items-center gap-2 text-green-900">
                <Check className="w-5 h-5" /> {t('conclusion_b1')}
              </li>
              <li className="flex items-center gap-2 text-green-900">
                <Check className="w-5 h-5" /> {t('conclusion_b2')}
              </li>
              <li className="flex items-center gap-2 text-green-900">
                <Check className="w-5 h-5" /> {t('conclusion_b3')}
              </li>
              <li className="flex items-center gap-2 text-green-900">
                <Check className="w-5 h-5" /> {t('conclusion_b4')}
              </li>
            </ul>
          </div>

          <Button 
            onClick={() => setStep('offer')}
            className="w-full py-8 md:py-10 text-xl font-black bg-primary hover:bg-primary/90 text-white rounded-2xl md:rounded-[2rem] shadow-xl transition-all hover:scale-105 active:scale-95 uppercase tracking-widest h-auto"
          >
            {t('conclusion_see_plan')}
          </Button>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#F7F3EA] p-4 sm:p-6 md:p-8 flex flex-col items-center justify-center">
      <Card className="w-full max-w-md p-6 sm:p-10 bg-white rounded-[2.5rem] sm:rounded-[3.5rem] shadow-2xl text-center relative overflow-hidden border-none">
        <div className="absolute top-0 left-0 w-full h-3 bg-primary"></div>
        
        <h2 className="text-2xl font-bold mb-2">{t('offer_title')}</h2>
        <p className="text-gray-600 mb-8">{t('offer_subtitle')}</p>

        <div className="mb-8 p-8 border-2 border-primary bg-primary/5 rounded-3xl text-center">
          <p className="text-sm text-primary font-bold uppercase tracking-wider mb-2">{t('offer_badge')}</p>
          <div className="flex items-center justify-center gap-2 mb-2">
            <span className="text-gray-400 line-through text-lg">{getCurrencySymbol()} 49.90</span>
            <span className="text-4xl font-black text-[#1F2937]">{getCurrencySymbol()} 19.90</span>
          </div>

          <p className="text-xs text-gray-500">{t('offer_one_time')}</p>
        </div>

        <ul className="space-y-4 mb-8 text-left px-2">
          {[t('offer_b1'), t('offer_b2'), t('offer_b3'), t('offer_b4')].map(b => (
            <li key={b} className="flex items-center space-x-3 text-gray-700">
              <Check className="w-5 h-5 text-green-500 shrink-0" />
              <span className="text-base font-medium">{b}</span>
            </li>
          ))}
        </ul>

        <Button
          onClick={() => {
            trackEvent('checkout_clicked');
            const stripeUrl = import.meta.env.VITE_STRIPE_PAYMENT_LINK;
            if (!stripeUrl) {
              console.error("VITE_STRIPE_PAYMENT_LINK is not configured.");
              return;
            }
            window.location.href = stripeUrl;
          }}
          className="w-full py-8 md:py-10 text-xl md:text-2xl font-black bg-primary hover:bg-primary/90 text-white rounded-2xl md:rounded-[2.5rem] shadow-xl transition-all hover:scale-105 active:scale-95 h-auto uppercase tracking-widest"
        >
          {t('offer_cta')}
        </Button>
        
        <div className="mt-6 flex items-center justify-center gap-4 grayscale opacity-50">
          <img src="https://upload.wikimedia.org/wikipedia/commons/b/ba/Stripe_Logo%2C_revised_2016.svg" alt="Stripe" className="h-6" />
        </div>
      </Card>
    </div>
  );
}
