import i18n from './config';
import { supabase } from '@/integrations/supabase/client';

const COUNTRY_CACHE_KEY = 'mente_ativa_country';
const LANG_CACHE_KEY = 'mente_ativa_lang';

const HISPANIC_COUNTRIES = new Set([
  'MX', 'AR', 'CO', 'CL', 'PE', 'VE', 'EC', 'BO', 'PY', 'UY',
  'CR', 'PA', 'DO', 'CU', 'GT', 'HN', 'SV', 'NI', 'PR', 'ES',
]);

const COUNTRY_CURRENCY: Record<string, string> = {
  BR: 'R$',
  ES: '€',
  PE: 'S/',
  BO: 'Bs.',
  PY: '₲',
  MX: '$',
  AR: '$',
  CL: '$',
  CO: '$',
  UY: '$',
  US: '$',
};

export const getCurrencySymbol = (country?: string | null): string => {
  if (country) return COUNTRY_CURRENCY[country.toUpperCase()] || '$';
  
  const stored = typeof window !== 'undefined' ? localStorage.getItem(COUNTRY_CACHE_KEY) : null;
  return COUNTRY_CURRENCY[stored?.toUpperCase() || 'BR'] || '$';
};


export const countryToLanguage = (country: string): 'pt' | 'es' | 'en' => {
  const c = country?.toUpperCase();
  if (c === 'BR' || c === 'PT') return 'pt';
  if (HISPANIC_COUNTRIES.has(c)) return 'es';
  return 'en';
};

const fetchCountryByIp = async (): Promise<string | null> => {
  try {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 1500); // Mais agressivo: 1.5s
    const res = await fetch('https://ipapi.co/json/', { 
      cache: 'no-store',
      signal: controller.signal 
    });
    clearTimeout(timeoutId);
    if (!res.ok) return null;
    const data = await res.json();
    return data?.country_code || null;
  } catch (err) {
    console.warn("Country detection failed, falling back to browser language");
    return null;
  }
};

export const applyLocale = (country: string | null) => {
  const safeCountry = country || 'BR';
  const lang = countryToLanguage(safeCountry);
  if (typeof window !== 'undefined') {
    localStorage.setItem(COUNTRY_CACHE_KEY, safeCountry);
    localStorage.setItem(LANG_CACHE_KEY, lang);
  }
  if (i18n.language !== lang) i18n.changeLanguage(lang);
  return { country: safeCountry, lang };
};

export const getStoredCountry = (): string | null => {
  if (typeof window === 'undefined') return null;
  return localStorage.getItem(COUNTRY_CACHE_KEY);
};

export const getStoredLanguage = (): string | null => {
  if (typeof window === 'undefined') return null;
  return localStorage.getItem(LANG_CACHE_KEY);
};

let initialized = false;

export const initLocale = async () => {
  if (typeof window === 'undefined' || initialized) return;
  initialized = true;

  // 1) Cache local - Prioridade absoluta para velocidade
  const stored = getStoredCountry();
  if (stored) {
    applyLocale(stored);
    return;
  }

  // 2) Preferência salva no DB (apenas se logado e rápido)
  try {
    const { data: { session } } = await supabase.auth.getSession();
    if (session?.user) {
      const { data: prefs } = await supabase
        .from('user_preferences')
        .select('country')
        .eq('user_id', session.user.id)
        .maybeSingle();
      if (prefs?.country) {
        applyLocale(prefs.country);
        return;
      }
    }
  } catch {}

  // 3) Detecção por IP
  const country = await fetchCountryByIp();
  if (country) {
    applyLocale(country);
    // Persiste pro usuário logado
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (user) {
        await supabase.from('user_preferences').upsert(
          { user_id: user.id, country, language: countryToLanguage(country) },
          { onConflict: 'user_id' }
        );
      }
    } catch {}
    return;
  }

  // 4) Fallback navegador
  const navLang = navigator.language?.slice(0, 2).toLowerCase();
  if (navLang === 'es') applyLocale('MX');
  else if (navLang === 'en') applyLocale('US');
  else applyLocale('BR');
};

export const setLocaleManually = async (country: string) => {
  applyLocale(country);
  try {
    const { data: { user } } = await supabase.auth.getUser();
    if (user) {
      await supabase.from('user_preferences').upsert(
        { user_id: user.id, country, language: countryToLanguage(country) },
        { onConflict: 'user_id' }
      );
    }
  } catch {}
};
